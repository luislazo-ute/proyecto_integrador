import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { StockBodega } from './entities/stock-bodega.entity';

@Module({
  imports: [TypeOrmModule.forFeature([StockBodega])],
  exports: [TypeOrmModule],
})
export class StockBodegaModule {}
