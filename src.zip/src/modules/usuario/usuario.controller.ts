import { Body, Controller, Delete, Get, Param, Post, Put, UseGuards } from "@nestjs/common";
import { Roles } from "src/common/decorators/roles.decorator";
import { JwtAuthGuard } from "src/common/guards/jwt-auth.guard";
import { RolesGuard } from "src/common/guards/roles.guard";
import { CreateUsuarioDto } from "./dto/create-usuario.dto";
import { UsuarioService } from "./usuario.service";
import { UpdateUsuarioDto } from "./dto/update-usuario.dto";

@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('usuario')
export class UsuarioController {
  constructor(private readonly usuarioService: UsuarioService) {}

  @Roles('ADMIN', 'BODEGA')
  @Get('responsables/list')
  responsables() {
    return this.usuarioService.findResponsables(); // lo creas en service
  }

  @Roles('ADMIN')
  @Post()
  create(@Body() dto: CreateUsuarioDto) {
    return this.usuarioService.create(dto);
  }

  @Roles('ADMIN')
  @Get()
  findAll() {
    return this.usuarioService.findAll();
  }

  @Roles('ADMIN')
  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.usuarioService.findOne(id);
  }

  @Roles('ADMIN')
  @Put(':id')
  update(@Param('id') id: string, @Body() dto: UpdateUsuarioDto) {
    return this.usuarioService.update(id, dto);
  }

  @Roles('ADMIN')
  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.usuarioService.remove(id);
  }

  // ✅ ESTE endpoint sí lo pueden ver ADMIN y BODEGA
  
}
