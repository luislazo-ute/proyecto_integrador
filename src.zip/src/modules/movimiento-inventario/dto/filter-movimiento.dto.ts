export class FilterMovimientoDto {
  id_producto?: string;
  id_bodega?: string;
  tipo_movimiento?: string;
  fecha_inicio?: Date;
  fecha_fin?: Date;
}
