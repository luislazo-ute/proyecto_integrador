import { Injectable, BadRequestException, NotFoundException, ForbiddenException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

import { Movimiento } from './entities/movimiento.entity';
import { MovimientoDetalle } from './entities/movimiento-detalle.entity';


import { StockBodega } from 'src/modules/stock-bodega/entities/stock-bodega.entity';
import { Producto } from 'src/modules/producto/entities/producto.entity';
import { Bodega } from 'src/modules/bodega/entities/bodega.entity';
import { Kardex } from 'src/modules/kardex/entities/kardex.entity';

import { CreateMovimientoDto } from './dto/create-movimiento.dto';
import { UsuarioService } from 'src/modules/usuario/usuario.service';
import { MovimientoSeq } from './entities/movimiento_seq.entity';

function formatMov(n: number) {
  return `MOV-${String(n).padStart(6, '0')}`;
}

@Injectable()
export class MovimientoInventarioService {
  constructor(
    @InjectRepository(Movimiento)
    private readonly movRepo: Repository<Movimiento>,

    @InjectRepository(MovimientoDetalle)
    private readonly detRepo: Repository<MovimientoDetalle>,

    @InjectRepository(MovimientoSeq)
    private readonly seqRepo: Repository<MovimientoSeq>,

    @InjectRepository(StockBodega)
    private readonly stockRepo: Repository<StockBodega>,

    @InjectRepository(Producto)
    private readonly prodRepo: Repository<Producto>,

    @InjectRepository(Bodega)
    private readonly bodegaRepo: Repository<Bodega>,

    @InjectRepository(Kardex)
    private readonly kardexRepo: Repository<Kardex>,

    private readonly usuarioService: UsuarioService,
  ) {}

  async findAll() {
    return this.movRepo.find({ order: { fecha_movimiento: 'DESC' as any } });
  }

  async findOne(id: string) {
    const mov = await this.movRepo.findOne({ where: { id_movimiento: id } });
    if (!mov) throw new NotFoundException('Movimiento no encontrado');
    return mov;
  }

  /**
   * Transferencia entre bodegas (documento tipo SALIDA).
   * - ADMIN: puede indicar origen/destino
   * - BODEGA: origen se fuerza a la bodega del usuario
   */
  async createTransfer(dto: CreateMovimientoDto, auth: { userId: string; role: string | null }) {
    if (!auth?.userId) throw new ForbiddenException('No autenticado');

    if (dto.id_bodega_origen === dto.id_bodega_destino) {
      throw new BadRequestException('La bodega origen y destino no pueden ser la misma');
    }

    if (!dto.items?.length) throw new BadRequestException('Debes enviar al menos un producto');

    // consolidar items repetidos
    const merged = new Map<string, number>();
    for (const it of dto.items) {
      merged.set(it.id_producto, (merged.get(it.id_producto) ?? 0) + Number(it.cantidad || 0));
    }
    const items = [...merged.entries()].map(([id_producto, cantidad]) => ({ id_producto, cantidad }));
    if (items.some(i => i.cantidad <= 0)) throw new BadRequestException('Cantidad inválida');

    // obtener usuario (Mongo) para conocer su bodega
    const user = await this.usuarioService.findOne(auth.userId);
    const userBodega = (user as any).id_bodega ?? null;

    // si es BODEGA, forzamos origen = su bodega
    const role = auth.role;
    let idOrigen = dto.id_bodega_origen;
    if (role === 'BODEGA') {
      if (!userBodega) throw new BadRequestException('El usuario no tiene bodega asignada');
      idOrigen = userBodega;
    }

    const idDestino = dto.id_bodega_destino;

    // validar bodegas existen
    const [b1, b2] = await Promise.all([
      this.bodegaRepo.findOne({ where: { id_bodega: idOrigen } }),
      this.bodegaRepo.findOne({ where: { id_bodega: idDestino } }),
    ]);
    if (!b1) throw new NotFoundException('Bodega origen no existe');
    if (!b2) throw new NotFoundException('Bodega destino no existe');

    // transacción para consistencia + locks
    return this.movRepo.manager.transaction(async (manager) => {
      // 1) generar secuencial con lock
      let seq = await manager.findOne(MovimientoSeq, {
        where: {},
        lock: { mode: 'pessimistic_write' },
      });

      if (!seq) {
        const created = manager.create(MovimientoSeq, { last_seq: 0 });
        await manager.save(created);

        seq = await manager.findOne(MovimientoSeq, {
          where: { id: created.id },
          lock: { mode: 'pessimistic_write' },
        });
      }

      if (!seq) throw new Error('No se pudo inicializar el secuencial de movimientos');

      seq.last_seq += 1;
      await manager.save(seq);

      const codigo = formatMov(seq.last_seq);


      // 2) validar productos existen
      const prodIds = items.map(i => i.id_producto);
      const productos = await manager.findByIds(Producto, prodIds as any);
      if (productos.length !== prodIds.length) {
        throw new NotFoundException('Uno o más productos no existen');
      }

      // 3) aplicar stock por bodega con locks
      const warnings: string[] = [];

      for (const it of items) {
        // lock stock origen
        let sOrigen = await manager.findOne(StockBodega, {
          where: { id_producto: it.id_producto, id_bodega: idOrigen },
          lock: { mode: 'pessimistic_write' },
        });

        if (!sOrigen) {
          await manager.save(
            manager.create(StockBodega, {
              id_producto: it.id_producto,
              id_bodega: idOrigen,
              stock: 0,
            }),
          );

          sOrigen = await manager.findOne(StockBodega, {
            where: { id_producto: it.id_producto, id_bodega: idOrigen },
            lock: { mode: 'pessimistic_write' },
          });
        }

        if (!sOrigen) throw new Error('No se pudo inicializar stock origen');


        // lock stock destino
        let sDestino = await manager.findOne(StockBodega, {
          where: { id_producto: it.id_producto, id_bodega: idDestino },
          lock: { mode: 'pessimistic_write' },
        });

        if (!sDestino) {
          await manager.save(
            manager.create(StockBodega, {
              id_producto: it.id_producto,
              id_bodega: idDestino,
              stock: 0,
            }),
          );

          sDestino = await manager.findOne(StockBodega, {
            where: { id_producto: it.id_producto, id_bodega: idDestino },
            lock: { mode: 'pessimistic_write' },
          });
        }

        if (!sDestino) throw new Error('No se pudo inicializar stock destino');


        // aplicar transferencia: salida origen, entrada destino
        sOrigen.stock -= it.cantidad;
        sDestino.stock += it.cantidad;

        await manager.save([sOrigen, sDestino]);

        // warning si stock bajo en origen
        if (sOrigen.stock < 5) {
          warnings.push(`Stock bajo (<5) en origen para producto ${it.id_producto}. Queda: ${sOrigen.stock}`);
        }
      }

      // 4) guardar movimiento + detalles
      const mov = manager.create(Movimiento, {
        codigo,
        id_bodega_origen: idOrigen,
        id_bodega_destino: idDestino,
        id_usuario: auth.userId,
        fecha_movimiento: new Date(),
        observacion: dto.observacion ?? null,
        detalles: items.map(it =>
          manager.create(MovimientoDetalle, {
            id_producto: it.id_producto,
            cantidad: it.cantidad,
          }),
        ),
      });

      const movGuardado = await manager.save(mov);

      // 5) kardex: registramos salida en origen y entrada en destino por cada item
      for (const it of items) {
        const sOrigen = await manager.findOne(StockBodega, {
          where: { id_producto: it.id_producto, id_bodega: idOrigen },
        });
        const sDestino = await manager.findOne(StockBodega, {
          where: { id_producto: it.id_producto, id_bodega: idDestino },
        });

        // salida origen
        await manager.save(
          manager.create(Kardex, {
            id_producto: it.id_producto,
            id_bodega: idOrigen,
            id_usuario: auth.userId,
            fecha: new Date(),
            tipo: 'salida',
            cantidad: it.cantidad,
            saldo: sOrigen?.stock ?? 0,
            descripcion: dto.observacion ?? `Transferencia a ${b2.nombre}`,
            id_movimiento: movGuardado.id_movimiento,
          }),
        );

        // entrada destino (para trazabilidad)
        await manager.save(
          manager.create(Kardex, {
            id_producto: it.id_producto,
            id_bodega: idDestino,
            id_usuario: auth.userId,
            fecha: new Date(),
            tipo: 'entrada',
            cantidad: it.cantidad,
            saldo: sDestino?.stock ?? 0,
            descripcion: dto.observacion ?? `Transferencia desde ${b1.nombre}`,
            id_movimiento: movGuardado.id_movimiento,
          }),
        );
      }

      return {
        mensaje: 'Movimiento registrado con éxito',
        movimiento: movGuardado,
        warnings,
      };
    });
  }
}
