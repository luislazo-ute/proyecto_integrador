import {
  Injectable,
  NotFoundException,
  BadRequestException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, Connection } from 'typeorm';
import { GuiaRemision } from './entities/guia-remision.entity';
import { DetalleGuiaRemision } from './entities/detalle-guia.entity';
import { CreateGuiaDto } from './dto/create-guia.dto';
import { AddDetalleGuiaDto } from './dto/add-detalle-guia.dto';
import { Producto } from 'src/modules/producto/entities/producto.entity';
import { RutaEntrega } from 'src/modules/ruta-entrega/entities/ruta-entrega.entity';
import { Transporte } from 'src/modules/transporte/entities/transporte.entity';
import { Conductor } from 'src/modules/conductor/entities/conductor.entity';

@Injectable()
export class GuiaRemisionService {
  constructor(
    @InjectRepository(GuiaRemision) private guiaRepo: Repository<GuiaRemision>,
    @InjectRepository(DetalleGuiaRemision)
    private detalleRepo: Repository<DetalleGuiaRemision>,
    @InjectRepository(Producto) private productoRepo: Repository<Producto>,
    @InjectRepository(RutaEntrega) private rutaRepo: Repository<RutaEntrega>,
    @InjectRepository(Transporte)
    private transporteRepo: Repository<Transporte>,
    @InjectRepository(Conductor) private conductorRepo: Repository<Conductor>,
    private readonly connection: Connection,
  ) {}

  private async generateNumeroGuia(): Promise<string> {
    const pad2 = (n: number) => n.toString().padStart(2, '0');
    const now = new Date();
    const stamp = `${now.getFullYear()}${pad2(now.getMonth() + 1)}${pad2(now.getDate())}`;

    for (let attempt = 0; attempt < 5; attempt++) {
      const rand = Math.floor(Math.random() * 1_000_000)
        .toString()
        .padStart(6, '0');
      const numero = `GR-${stamp}-${rand}`;

      const exists = await this.guiaRepo.exist({
        where: { numero_guia: numero },
      });
      if (!exists) return numero;
    }

    throw new BadRequestException('No se pudo generar un número de guía único');
  }

  async create(dto: CreateGuiaDto) {
    const ruta = await this.rutaRepo.findOne({
      where: { id_ruta: dto.id_ruta },
    });
    if (!ruta) throw new NotFoundException('Ruta no encontrada');

    const transporte = await this.transporteRepo.findOne({
      where: { id_transporte: dto.id_transporte },
    });
    if (!transporte) throw new NotFoundException('Transporte no encontrado');

    const conductor = await this.conductorRepo.findOne({
      where: { id_conductor: dto.id_conductor },
    });
    if (!conductor) throw new NotFoundException('Conductor no encontrado');

    const numero_guia = dto.numero_guia?.trim()
      ? dto.numero_guia.trim()
      : await this.generateNumeroGuia();

    const guia = this.guiaRepo.create({
      ...dto,
      numero_guia,
      ruta,
      fecha_emision: new Date(),
      estado: 'emitida',
      peso_total: 0,
    });

    return this.guiaRepo.save(guia);
  }

  async addDetalle(dto: AddDetalleGuiaDto) {
    const guia = await this.guiaRepo.findOne({
      where: { id_guia: dto.id_guia },
    });

    if (!guia) {
      throw new NotFoundException('Guía no encontrada');
    }

    if (guia.estado !== 'emitida') {
      throw new BadRequestException(
        'No se pueden agregar productos a una guía que no esté emitida',
      );
    }

    const producto = await this.productoRepo.findOne({
      where: { id_producto: dto.id_producto },
    });

    if (!producto) {
      throw new NotFoundException('Producto no encontrado');
    }

    const transporte = await this.transporteRepo.findOne({
      where: { id_transporte: guia.id_transporte },
    });

    if (!transporte) {
      throw new NotFoundException('Transporte no encontrado');
    }

    const pesoDetalle = Number(producto.peso) * Number(dto.cantidad);

    const nuevoPesoTotal = Number(guia.peso_total) + pesoDetalle;

    if (nuevoPesoTotal > Number(transporte.capacidad)) {
      throw new BadRequestException(
        `No se puede agregar el producto. 
       Peso actual: ${guia.peso_total} kg, 
       nuevo peso: ${nuevoPesoTotal} kg, 
       capacidad máxima: ${transporte.capacidad} kg`,
      );
    }

    const detalle = this.detalleRepo.create({
      ...dto,
      peso_total: pesoDetalle,
    });

    await this.detalleRepo.save(detalle);

    guia.peso_total = nuevoPesoTotal;
    await this.guiaRepo.save(guia);

    return {
      message: 'Detalle agregado correctamente',
      detalle,
      peso_total_guia: guia.peso_total,
    };
  }

  async enviar(id: string) {
    const guia = await this.guiaRepo.findOne({ where: { id_guia: id } });

    if (!guia) {
      throw new NotFoundException('Guía no encontrada');
    }

    if (guia.estado !== 'emitida') {
      throw new BadRequestException(
        'La guía no se puede enviar en su estado actual',
      );
    }

    const transporte = await this.transporteRepo.findOne({
      where: { id_transporte: guia.id_transporte },
    });

    if (!transporte) {
      throw new NotFoundException('Transporte no encontrado');
    }

    if (Number(guia.peso_total) > Number(transporte.capacidad)) {
      throw new BadRequestException(
        `El peso total de la guía (${guia.peso_total} kg) excede la capacidad del transporte (${transporte.capacidad} kg)`,
      );
    }

    transporte.estado = 'en ruta';
    await this.transporteRepo.save(transporte);

    guia.estado = 'en transito';
    guia.fecha_inicio_transporte = new Date();

    return this.guiaRepo.save(guia);
  }

  async finalizar(id: string) {
    const guia = await this.guiaRepo.findOne({ where: { id_guia: id } });
    if (!guia) throw new NotFoundException('Guía no encontrada');

    const transporte = await this.transporteRepo.findOne({
      where: { id_transporte: guia.id_transporte },
    });

    if (!transporte) {
      throw new NotFoundException('Transporte no encontrado.');
    }

    transporte.estado = 'disponible';
    await this.transporteRepo.save(transporte);

    guia.estado = 'finalizada';
    guia.fecha_fin_transporte = new Date();

    return this.guiaRepo.save(guia);
  }

  findAll() {
    return this.guiaRepo.find({ relations: ['detalles'] });
  }

  findOne(id: string) {
    return this.guiaRepo.findOne({
      where: { id_guia: id },
      relations: ['detalles'],
    });
  }
}
